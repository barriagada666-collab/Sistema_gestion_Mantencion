#!/bin/bash
# ==============================================================================
# Lanzador directo con Whisky para macOS
# Sistema de Gestión Departamento Mantención - Cambiaso Hnos. S.A.C.
# ==============================================================================

DIR="$(cd "$(dirname "$0")" && pwd)"
APP_EXE="$DIR/Sistema de Gestión Mantención.app/Contents/Resources/app/Sistema de Gestion Mantencion.exe"
if [[ ! -f "$APP_EXE" ]]; then
    APP_EXE="/Applications/Sistema de Gestión Mantención.app/Contents/Resources/app/Sistema de Gestion Mantencion.exe"
fi

clear
echo "=========================================================="
echo "  SISTEMA DE GESTIÓN MANTENCIÓN - LANZADOR WHISKY"
echo "  Cambiaso Hnos. S.A.C. - División Mantención Industrial"
echo "=========================================================="
echo ""

WHISKY_PATH=""
if [[ -d "/Applications/Whisky.app" ]]; then
    WHISKY_PATH="/Applications/Whisky.app"
elif [[ -d "$HOME/Applications/Whisky.app" ]]; then
    WHISKY_PATH="$HOME/Applications/Whisky.app"
fi

if [[ -n "$WHISKY_PATH" ]]; then
    echo "✓ Whisky detectado en: $WHISKY_PATH"
    echo "Iniciando Sistema de Gestión Mantención en Whisky..."
    open -a "$WHISKY_PATH" "$APP_EXE"
    echo ""
    echo "¡Listo! La aplicación se está ejecutando a través de Whisky."
    sleep 2
    exit 0
else
    echo "[AVISO] Whisky no fue detectado en /Applications."
    echo "Puede instalar Whisky con Homebrew ejecutando:"
    echo "brew install --cask whisky"
    echo ""
    read -p "Presione Enter para salir..."
    exit 1
fi
