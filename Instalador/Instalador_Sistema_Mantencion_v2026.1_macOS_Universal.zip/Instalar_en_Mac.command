#!/bin/bash
# ==============================================================================
# Script de Instalación de 1-Clic para macOS
# Sistema de Gestión Departamento Mantención - Cambiaso Hnos. S.A.C.
# ==============================================================================

set -e
cd "$(dirname "$0")"

clear
echo "=========================================================="
echo "  INSTALADOR DE SISTEMA DE GESTIÓN MANTENCIÓN PARA MACOS"
echo "  Cambiaso Hnos. S.A.C. - División de Mantención Industrial"
echo "  Arquitectura: $(uname -m) (Universal Apple Silicon / Intel)"
echo "=========================================================="
echo ""

APP_SRC="Sistema de Gestión Mantención.app"
APP_DEST="/Applications/Sistema de Gestión Mantención.app"

if [[ ! -d "$APP_SRC" ]]; then
    echo "[ERROR] No se encontró '$APP_SRC' en el directorio actual."
    exit 1
fi

echo "[1/3] Copiando aplicación hacia la carpeta /Applications..."
rm -rf "$APP_DEST"
cp -R "$APP_SRC" "$APP_DEST"

echo "[2/3] Configurando permisos y removiendo cuarentena de macOS Gatekeeper..."
xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true
chmod -R 755 "$APP_DEST"

echo "[3/3] Verificando motor de compatibilidad Whisky / Wine..."
MOTOR_ENCONTRADO=0

if [[ -d "/Applications/Whisky.app" ]] || [[ -d "$HOME/Applications/Whisky.app" ]]; then
    echo "       ✓ [OK] Whisky detectado en Aplicaciones."
    MOTOR_ENCONTRADO=1
fi

if command -v wine &>/dev/null || command -v wine64 &>/dev/null || [[ -x "/opt/homebrew/bin/wine" ]]; then
    echo "       ✓ [OK] Motor Wine detectado en el sistema."
    MOTOR_ENCONTRADO=1
fi

if [[ $MOTOR_ENCONTRADO -eq 0 ]]; then
    echo ""
    echo "       [AVISO] Se recomienda instalar Whisky para macOS:"
    echo "       brew install --cask whisky"
    echo ""
fi

echo ""
echo "=========================================================="
echo "  ¡INSTALACIÓN COMPLETADA EXITOSAMENTE!"
echo "  Puede abrir la aplicación desde Launchpad o /Applications"
echo "=========================================================="
echo ""
read -p "Presione Enter para salir o abrir la aplicación... " -n 1 -r
open "$APP_DEST" || true
